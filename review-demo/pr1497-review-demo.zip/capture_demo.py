# Copyright (c) 2026, solvcon team <contact@solvcon.net>
# BSD 3-Clause License, see COPYING

"""Exercise the real demo and capture its rendered window."""

import json
from pathlib import Path
import statistics
import tempfile
import time

from PySide6 import QtCore, QtTest, QtWidgets

from solvcon.benchmark.artifact import load_artifact

from demo import Demo


def wait_for(predicate, timeout=120):
    deadline = time.monotonic() + timeout
    while not predicate():
        if time.monotonic() >= deadline:
            raise RuntimeError('Timed out waiting for the demo')
        QtTest.QTest.qWait(20)


def main():
    app = QtWidgets.QApplication([])
    app.setQuitOnLastWindowClosed(False)
    folder = Path(__file__).resolve().parent
    evidence = {'qt': QtCore.qVersion(), 'platform': app.platformName()}
    with tempfile.TemporaryDirectory(prefix='pr1497-demo-') as output:
        window = Demo(400, 10, output)
        control = window.control
        events = []
        control.completed.connect(lambda path: events.append(
            ('completed', path)))
        control.failed.connect(lambda error: events.append(('failed', error)))
        control.stopped.connect(lambda: events.append(('stopped', None)))
        window.show()
        wait_for(lambda: window.windowHandle().isExposed(), timeout=10)

        try:
            QtTest.QTest.mouseClick(
                window.run_button, QtCore.Qt.MouseButton.LeftButton)
            wait_for(lambda: control.status.text().startswith('Timing:')
                     and control._clock.elapsed() >= 1000)
            assert control.running and control.stop_button.isEnabled()
            assert window.results.rowCount() == 0
            assert not window.run_button.isEnabled()
            assert control._process.processId() > 0
            assert window.grab().save(str(folder / 'running.png'))
            evidence['running'] = {
                'status': control.status.text(),
                'elapsed': control.elapsed.text(),
                'worker_pid': control._process.processId(),
            }

            started = time.monotonic()
            QtTest.QTest.mouseClick(
                control.stop_button, QtCore.Qt.MouseButton.LeftButton)
            wait_for(lambda: len(events) == 1, timeout=10)
            assert events == [('stopped', None)]
            assert control.status.text() == 'Stopped'
            assert 'No completed results' in window.message.text()
            assert window.results.rowCount() == 0
            assert window.run_button.isEnabled()
            assert not control.stop_button.isEnabled()
            assert control._process.state() == (
                QtCore.QProcess.ProcessState.NotRunning)
            assert not list(Path(output).glob('*.json'))
            QtTest.QTest.qWait(100)
            assert window.grab().save(str(folder / 'stopped.png'))
            evidence['stopped'] = {
                'seconds_after_click': time.monotonic() - started,
                'worker_exited': True, 'artifact_written': False,
            }
            print('Captured running and stopped states', flush=True)

            QtTest.QTest.mouseClick(
                window.run_button, QtCore.Qt.MouseButton.LeftButton)
            assert window.results.rowCount() == 0
            assert not window.artifact_path.text()
            evidence['rerun_clears_results'] = True
            wait_for(lambda: len(events) == 2)
            assert events[1][0] == 'completed', events
            document = load_artifact(events[1][1])
            assert document['spec'] == window.spec.to_dict()
            assert control.status.text() == 'Completed'
            assert window.run_button.isEnabled()
            assert window.results.rowCount() == len(document['results'])
            rows = []
            for row, result in enumerate(document['results']):
                cells = [window.results.item(row, col).text()
                         for col in range(5)]
                median = statistics.median(result['round_elapsed_ns'])
                milliseconds = median / window.spec.sampling.repetitions / 1e6
                assert cells[:2] == [result['name'], result['status']]
                assert cells[2] == f'{milliseconds:.6f}'
                assert cells[3] == f"{result['max_abs_diff']:.6g}"
                assert cells[4] == f"{result['relative_diff']:.6g}"
                rows.append(cells)
            assert Path(window.artifact_path.text()).is_file()
            evidence['displayed_results'] = rows
            QtTest.QTest.qWait(100)
            assert window.grab().save(str(folder / 'completed.png'))
            (folder / 'completed-artifact.json').write_text(
                Path(events[1][1]).read_text())
            evidence['restart_completed'] = True

            QtTest.QTest.mouseClick(
                window.run_button, QtCore.Qt.MouseButton.LeftButton)
            assert window.results.rowCount() == 0
            assert not window.artifact_path.text()
            wait_for(lambda: control.status.text().startswith('Timing:'))
            window.close()
            wait_for(lambda: not window.isVisible() and len(events) == 3,
                     timeout=10)
            assert events[2] == ('stopped', None)
            assert control._process.state() == (
                QtCore.QProcess.ProcessState.NotRunning)
            evidence['close_stops_worker'] = True
            evidence['signals'] = [kind for kind, _ in events]

            failure = Demo(2, 1, Path(output) / 'failure')
            blocked = Path(output) / 'not-a-directory'
            blocked.write_text('Exercise a real worker output error.')
            failure.output_dir = blocked
            failure.show()
            failure.run_button.click()
            wait_for(lambda: not failure.control.running)
            assert failure.message.text().startswith('Failed:')
            assert failure.results.rowCount() == 0
            assert failure.run_button.isEnabled()
            evidence['failure_message'] = failure.message.text()
            QtTest.QTest.qWait(100)
            assert failure.grab().save(str(folder / 'failed.png'))
            failure.output_dir = Path(output) / 'failure'
            failure.run_button.click()
            wait_for(lambda: not failure.control.running)
            assert failure.results.rowCount() == 2
            evidence['failure_recovery'] = True
            failure.close()
            (folder / 'verification.json').write_text(
                json.dumps(evidence, indent=2) + '\n')
            print(json.dumps(evidence, indent=2), flush=True)
        finally:
            control.stop()
            wait_for(lambda: not control.running, timeout=10)
            window.close()


if __name__ == '__main__':
    main()

# vim: set ff=unix fenc=utf8 et sw=4 ts=4 sts=4 tw=79:
