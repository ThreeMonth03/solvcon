# Verification

Source: PR #1497, commit `c2eeba9fe4441d1501c47d5b1aae5c5a56855e5e`.
The checkout has no source changes. Demo materials are outside the checkout.

Environment: WSL2, Python 3.12.7, PySide6/Qt 6.8.0, X11 (`xcb`).
OpenBLAS, OpenMP, MKL, and Accelerate thread variables were set to one.

## Results

| Acceptance criterion | Result | Evidence |
| --- | --- | --- |
| Real worker reports a kernel and elapsed time | Passed | `running.png` |
| Stop ends the worker and enables another run | Passed | `stopped.png` |
| A rerun completes and writes a valid artifact | Passed | `completed.png`, `completed-artifact.json` |
| Result table matches artifact values and per-call timing | Passed | `verification.json` |
| Another Run clears old rows and artifact path | Passed | `verification.json` |
| Output failure is visible and another run recovers | Passed | `failed.png`, `verification.json` |
| Entry point works outside the checkout with no PYTHONPATH | Passed | `portable-verification.json` |
| Output directory names containing spaces work | Passed | `portable-verification.json` |
| Closing during a run ends the worker | Passed | `verification.json` |
| Controller and progress regression tests | Passed | 8 passed, 2496 deselected |
| Demo Python style and shell syntax | Passed | flake8 and `bash -n` |

`verification.json` records the visible status, worker PID, and terminal
signal sequence: stopped, completed, stopped. Screenshots capture the real
visible window's content through `QWidget.grab()`, without window decorations.
All demo verification workers and windows were stopped on completion.
Temporary verification output was removed after preserving one result.

The portable entry-point check used a fresh Python process with an empty
PYTHONPATH, a temporary current directory containing spaces, explicit
`--repo`, and a relative output directory containing spaces. Qt automation
clicked Run, checked the displayed rows, and closed the window. The imported
solvcon module came from the requested checkout.

The table check compared displayed cells with the actual artifact, including
dividing repetition-block timing by the repetition count. A filesystem path
whose parent was a regular file caused a real worker failure; the demo showed
the error and completed a subsequent run with a valid destination.

The 8 controller/progress regression tests below were run in the initial
verification of this unchanged PR commit. This revision reran the real demo
checks and lint after adding the result table and portable entry point.

## Commands

Build, with the existing dependency prefix on PATH and its library directory
on LD_LIBRARY_PATH:

```bash
make CMAKE_PRESET=dev-noqt \
    CMAKE_PREFIX_PATH=/home/threemonth03/devenv/flavors/prime/usr \
    CMAKE_ARGS=-Dpybind11_DIR=/home/threemonth03/devenv/flavors/prime/usr/lib/python3.12/site-packages/pybind11/share/cmake/pybind11 \
    NPROC=4
```

Capture, from the PR checkout with that same environment:

```bash
export PYTHONPATH="$PWD"
export QT_QPA_PLATFORM=xcb
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1
python3 /home/threemonth03/Downloads/pr1497-review-demo/capture_demo.py
```

Existing regression tests:

```bash
make pytest \
    PYTEST_OPTS="-q -k 'BenchmarkControlTC or BenchmarkProgressTC'" NPROC=4
```

Demo lint, using the same Python:

```bash
python3 -m flake8 /home/threemonth03/Downloads/pr1497-review-demo/demo.py \
    /home/threemonth03/Downloads/pr1497-review-demo/capture_demo.py
bash -n /home/threemonth03/Downloads/pr1497-review-demo/run-local.sh
```

## Limits

The standalone PySide6 control was exercised with the actual numerical
extension and worker. The C++ Pilot executable, embedded interpreter, and
future Inspector page were not exercised. These runs establish UI behavior,
not benchmark performance. Full repository lint was not rerun because no
repository source was edited or pushed.

<!-- vim: set ff=unix fenc=utf8 et sw=4 ts=4 sts=4 tw=79: -->
